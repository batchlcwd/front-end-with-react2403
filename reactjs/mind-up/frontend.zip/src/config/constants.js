export const ROLE_ADMIN = "ROLE_ADMIN";
export const ROLE_GUEST = "ROLE_GUEST";
