import React from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  return (
    <div>
      <Helmet>
        <title>ContactUs | Mindup</title>
      </Helmet>
      <div>Contact</div>
    </div>
  );
};

export default Contact;
