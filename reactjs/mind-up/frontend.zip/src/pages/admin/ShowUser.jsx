import React from "react";

const ShowUser = () => {
  return <div>ShowUser</div>;
};

export default ShowUser;
