import React from "react";
import { Helmet } from "react-helmet";

const Services = () => {
  return (
    <div>
      <Helmet>
        <title>Services Provided | Mindup</title>
      </Helmet>
      <div>Services</div>
    </div>
  );
};

export default Services;
